#Main file
import CallUI
import gisax

#I will do a thorough code clean up!
def setUp():
    CallUI.setUpWindow()


if __name__ == "__main__":
    setUp()
