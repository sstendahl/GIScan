# GIScan
Simple tool to read and analyze existing GISAXS data. 
This software has only been tested on GISXAS-data obtained at DESY in Germany, exported to a .dat file by PyMCa. Any other type of data is unsupported.

Very early alpha. 
The total feature set of this program will be quite limited, but is planned to contain at least:

* Coordinate conversions from pixels to angles and q
* Automated scans for specific coordinates (detector scan, yoneda scan, bragg peak scan)

Note that this is an early alpha. The code is extremely messy at the moment, so a throrough code clean-up is also planned at some stage.
